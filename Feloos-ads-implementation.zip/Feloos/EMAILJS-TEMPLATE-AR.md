# مراجعة قالب EmailJS

أرسل التطبيق الحقول التالية في `template_params`. طابق أسماء المتغيرات في قالب EmailJS حرفيًا:

```text
request_id
player_name
amount
payment_method
phone
account_holder
snapshot_gems
snapshot_questions_seen
snapshot_answered
snapshot_correct
snapshot_wrong
title
```

الإعدادات الموجودة في التطبيق:
- Service ID: `service_feloos`
- Template ID: `template_re4e9yd`
- Public Key: موجود في كود العميل؛ لا يُعامل كمفتاح سري.
- To Email في قالب EmailJS: `alaasabryksa@gmail.com`
- Subject المقترح: `طلب سحب جديد - لعبة فِلوس`

نموذج محتوى القالب:

```html
<h2>{{title}}</h2>
<p>رقم الطلب: {{request_id}}</p>
<p>اسم اللاعب: {{player_name}}</p>
<p>المبلغ المطلوب: {{amount}} جنيه</p>
<p>وسيلة الدفع: {{payment_method}}</p>
<p>رقم المحفظة: {{phone}}</p>
<p>اسم صاحب المحفظة: {{account_holder}}</p>
<hr>
<p>الجواهر الظاهرة على الجهاز: {{snapshot_gems}}</p>
<p>الأسئلة المشاهدة محليًا: {{snapshot_questions_seen}}</p>
<p>إجابات الجولة الحالية: {{snapshot_answered}}</p>
<p>الصحيحة في الجولة الحالية: {{snapshot_correct}}</p>
<p>الخاطئة في الجولة الحالية: {{snapshot_wrong}}</p>
<p>الطلب تحت المراجعة اليدوية؛ لم يتم تحويل أموال تلقائيًا.</p>
```

ملاحظة: سبق اختبار وصول رسالة EmailJS، لكن ذلك لا يثبت وحده أن كل حقل ظهر في مكانه داخل قالب البريد. يمكن تأكيد المطابقة من الكود؛ يلزم إرسال اختبار من التطبيق أو من لوحة EmailJS لتأكيد شكل الرسالة النهائي. لا يلزم وجود بيانات لاعبين حقيقية للاختبار؛ استخدم بيانات تجريبية غير حساسة.
