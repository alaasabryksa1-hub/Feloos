# Feloos — question bank update

- Replaced the repetitive generated arithmetic block with a much broader Arabic general-knowledge bank.
- 1,000 total questions; unique IDs and unique exact question wording.
- Four distinct answer options per question and a valid correct-answer index.
- Topics include geography/capitals/currencies, science and chemistry, biology, nature, history, arts and literature, sports, technology, space, weather, environment, food, and everyday knowledge, plus arithmetic.
- Question levels: 333 easy, 333 medium, 334 hard.
- Updated Android WebView question asset to match `public/questions.js`.

## Automated checks performed

- `node --check public/questions.js`
- `node --check public/game.js`
- `node scripts/check-game.mjs`
- Parsed all 1,000 records and checked unique IDs, unique exact question text, four distinct choices, and valid answer indices.

## Limitations

These checks validate data structure and source consistency, not the factual correctness of every question or a complete real-device Android/AdMob/withdrawal test. Review nuanced historical/scientific items and test the app on a real device before public release.
