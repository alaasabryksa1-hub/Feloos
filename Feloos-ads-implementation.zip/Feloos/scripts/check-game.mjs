import { readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { strict as assert } from 'node:assert';

const read = (path) => readFileSync(path, 'utf8');
const game = read('public/game.js');
const questionsSource = read('public/questions.js');
const questionMatch = questionsSource.match(/window\.QUESTIONS\s*=\s*(\[.*\])\s*;?\s*$/s);
assert(questionMatch, 'questions.js must export window.QUESTIONS as a JSON array');
const questions = JSON.parse(questionMatch[1]);
assert(questions.length === 1000, `Question bank must contain exactly 1000 questions, got ${questions.length}`);
const ids = new Set();
const wording = new Set();
const levels = { easy: 0, medium: 0, hard: 0 };
for (const [index, question] of questions.entries()) {
  assert(typeof question.id === 'string' && question.id, `Question ${index + 1} needs an id`);
  assert(!ids.has(question.id), `Duplicate question id: ${question.id}`);
  ids.add(question.id);
  assert(typeof question.q === 'string' && question.q.trim(), `Question ${question.id} has no text`);
  assert(!wording.has(question.q.trim()), `Duplicate question wording: ${question.q}`);
  wording.add(question.q.trim());
  assert(Object.hasOwn(levels, question.level), `Unknown level in ${question.id}`);
  levels[question.level] += 1;
  assert(Array.isArray(question.a) && question.a.length === 4, `${question.id} must have exactly 4 answers`);
  assert(question.a.every((answer) => typeof answer === 'string' && answer.trim()), `${question.id} has an empty answer`);
  assert(Number.isInteger(question.c) && question.c >= 0 && question.c < 4, `${question.id} has an invalid correct-answer index`);
}
for (const [level, count] of Object.entries(levels)) assert(count > 0, `No questions configured for ${level}`);

const assets = 'android/app/src/main/assets/www';
assert(read(`${assets}/game.js`) === read('public/game.js'), 'Android game.js is out of sync with public/game.js');
assert(read(`${assets}/questions.js`) === read('public/questions.js'), 'Android questions.js is out of sync with public/questions.js');
assert(read(`${assets}/index.html`) === read('public/index.html'), 'Android index.html is out of sync with public/index.html');
assert(read(`${assets}/feloos.css`) === read('public/feloos.css'), 'Android feloos.css is out of sync with public/feloos.css');
for (const required of ['service_feloos', 'template_re4e9yd', 'api.emailjs.com/api/v1.0/email/send', 'request_id', 'snapshot_questions_seen']) {
  assert(game.includes(required), `Missing EmailJS/game integration marker: ${required}`);
}
assert(!game.includes('FELOOS_API_BASE'), 'Legacy separate API configuration must not be used');
assert(game.includes('inviteRewardClaimed') && game.includes('state.coins += 50'), 'One-time invite share reward is missing');
for (const path of ['public/game.js', 'public/questions.js', `${assets}/game.js`, `${assets}/questions.js`]) {
  execFileSync(process.execPath, ['--check', path], { stdio: 'inherit' });
}
console.log(`Game checks passed: ${questions.length} unique questions (${levels.easy} easy, ${levels.medium} medium, ${levels.hard} hard); source and Android assets are synchronized.`);
