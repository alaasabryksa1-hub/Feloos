package com.feloos.quiz

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAd
import com.google.android.gms.ads.rewardedinterstitial.RewardedInterstitialAdLoadCallback
import kotlin.math.min

/**
 * One rewarded-interstitial unit only.
 * Debug builds always request Google's demo unit. Release uses the live unit.
 */
class RewardedInterstitialController(
    private val activity: MainActivity,
) {
    private val handler = Handler(Looper.getMainLooper())
    private var rewarded: RewardedInterstitialAd? = null
    private var loading = false
    private var retries = 0
    private var retry: Runnable? = null
    var showing: Boolean = false
        private set

    private val adUnitId: String
        get() = BuildConfig.ADMOB_REWARDED_INTERSTITIAL_AD_UNIT_ID

    fun preload() {
        FeloosApp.whenReady { load() }
    }

    fun show(token: String) {
        handler.post {
            val ready = rewarded
            if (ready == null || activity.isFinishing || activity.isDestroyed) {
                activity.deliverReward(token, "unavailable")
                load()
                return@post
            }
            rewarded = null
            showing = true
            var earned = false
            var reported = false
            fun report(status: String) {
                if (reported) return
                reported = true
                activity.deliverReward(token, if (earned) "reward" else status)
            }
            ready.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    showing = false
                    if (!reported) report("dismiss")
                    load()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    showing = false
                    Log.w(TAG, "show failed: ${adError.message}")
                    if (!reported) report("unavailable")
                    load()
                }
            }
            try {
                ready.show(activity) {
                    earned = true
                    report("reward")
                }
            } catch (error: RuntimeException) {
                showing = false
                Log.w(TAG, "show threw", error)
                report("unavailable")
                load()
            }
        }
    }

    fun release() {
        showing = false
        retry?.let { handler.removeCallbacks(it) }
        handler.removeCallbacksAndMessages(null)
        rewarded = null
    }

    private fun load() {
        if (loading || rewarded != null || activity.isFinishing || activity.isDestroyed) return
        loading = true
        Log.d(TAG, if (BuildConfig.DEBUG) "loading demo rewarded interstitial" else "loading live rewarded interstitial")
        RewardedInterstitialAd.load(
            activity,
            adUnitId,
            AdRequest.Builder().build(),
            object : RewardedInterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedInterstitialAd) {
                    rewarded = ad
                    loading = false
                    retries = 0
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "load failed: ${error.message}")
                    rewarded = null
                    loading = false
                    retries += 1
                    val delay = min(120_000L, 15_000L * retries)
                    retry?.let { handler.removeCallbacks(it) }
                    val next = Runnable { load() }
                    retry = next
                    handler.postDelayed(next, delay)
                }
            },
        )
    }

    companion object {
        private const val TAG = "FeloosAds"
        const val TEST_REWARDED_INTERSTITIAL = "ca-app-pub-3940256099942544/5354046379"
        const val LIVE_REWARDED_INTERSTITIAL = "ca-app-pub-6809664188772391/7795014869"
    }
}
