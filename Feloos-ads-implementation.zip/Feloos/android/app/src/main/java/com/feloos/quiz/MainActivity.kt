package com.feloos.quiz

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.InterstitialAd
import com.google.android.gms.ads.InterstitialAdLoadCallback
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.android.ump.ConsentInformation
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var ads: RewardedInterstitialController
    private lateinit var nativeAdContainer: LinearLayout
    private lateinit var bannerAdContainer: LinearLayout
    private var bannerAdView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var interstitialLoading = false
    private var interstitialShowing = false
    private var lastInterstitialShownAt = 0L
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val appOpenPrefs by lazy { getSharedPreferences("feloos_ad_state", MODE_PRIVATE) }
    private var leavingForShare = false
    private var webReady = false
    private var activityResumed = false
    private var appOpenAd: AppOpenAd? = null
    private var appOpenLoading = false
    private var appOpenShowing = false
    private var nativeAd: NativeAd? = null
    private var nativeAdLoading = false
    private val appOpenCooldownMs = 4L * 60L * 60L * 1000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ads = RewardedInterstitialController(this)
        webView = WebView(this)
        nativeAdContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(10, 6, 10, 6)
            setBackgroundColor(android.graphics.Color.rgb(23, 18, 41))
        }
        bannerAdContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, 2, 0, 2)
            setBackgroundColor(android.graphics.Color.rgb(23, 18, 41))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(android.graphics.Color.rgb(23, 18, 41))
            addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(nativeAdContainer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(bannerAdContainer, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        setContentView(root)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.settings.allowFileAccess = true
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url?.toString().orEmpty()
                return !url.startsWith("file:///android_asset/")
            }
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                webReady = true
                maybeLoadOrShowAppOpenAd()
            }
        }
        webView.addJavascriptInterface(Bridge(), "FeloosNative")
        webView.loadUrl(GAME_URL)
        requestConsentAndInitializeAds()
        ads.preload()
        FeloosApp.whenReady { preloadInterstitialAd() }
        FeloosApp.whenReady { maybeLoadOrShowAppOpenAd() }
        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    webView.evaluateJavascript(BACK_JS) { result ->
                        if (result == null || result.contains("0")) finishAndRemoveTask()
                    }
                }
            },
        )
    }

    override fun onResume() {
        super.onResume()
        activityResumed = true
        leavingForShare = false
        if (!::webView.isInitialized || isDestroyed) return
        webView.resumeTimers()
        webView.onResume()
        webView.evaluateJavascript("window.feloosOnResume&&window.feloosOnResume()", null)
        maybeLoadOrShowAppOpenAd()
    }

    override fun onPause() {
        activityResumed = false
        hush()
        if (::webView.isInitialized) {
            webView.onPause()
            webView.pauseTimers()
        }
        super.onPause()
    }

    override fun onStop() {
        hush()
        super.onStop()
    }

    override fun onDestroy() {
        if (::ads.isInitialized) ads.release()
        nativeAd?.destroy()
        nativeAd = null
        bannerAdView?.destroy()
        bannerAdView = null
        interstitialAd = null
        appOpenAd = null
        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("FeloosNative")
            webView.destroy()
        }
        super.onDestroy()
    }

    private fun requestConsentAndInitializeAds() {
        val consentInformation = UserMessagingPlatform.getConsentInformation(this)
        val parameters = ConsentRequestParameters.Builder().build()
        consentInformation.requestConsentInfoUpdate(
            this,
            parameters,
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                    if (consentInformation.canRequestAds()) FeloosApp.initializeAds(this)
                }
            },
            { error ->
                android.util.Log.w("FeloosAds", "UMP consent update failed: ${error.message}; canRequestAds=${consentInformation.canRequestAds()}")
                if (consentInformation.canRequestAds()) FeloosApp.initializeAds(this)
            },
        )
        android.util.Log.d("FeloosAds", "Initial consent state: canRequestAds=${consentInformation.canRequestAds()}")
        if (consentInformation.canRequestAds()) FeloosApp.initializeAds(this)
    }

    private fun showPrivacyOptionsForm() {
        val consentInformation = UserMessagingPlatform.getConsentInformation(this)
        if (consentInformation.privacyOptionsRequirementStatus != ConsentInformation.PrivacyOptionsRequirementStatus.REQUIRED) {
            Toast.makeText(this, "لا توجد خيارات خصوصية إضافية مطلوبة حاليًا.", Toast.LENGTH_SHORT).show()
            return
        }
        UserMessagingPlatform.showPrivacyOptionsForm(this) { error ->
            if (error != null) Toast.makeText(this, "تعذر فتح خيارات الخصوصية حاليًا.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isEligibleForAppOpen(): Boolean {
        if (!webReady || !activityResumed || isFinishing || isDestroyed || appOpenShowing || ads.showing || leavingForShare) return false
        val raw = prefs.getString(STATE_KEY, "").orEmpty()
        val saved = try { JSONObject(raw) } catch (_: Exception) { return false }
        if (!saved.optBoolean("onboarded", false) || saved.optBoolean("signedOut", false)) return false
        return System.currentTimeMillis() - appOpenPrefs.getLong("last_shown", 0L) >= appOpenCooldownMs
    }

    private fun maybeLoadOrShowAppOpenAd() {
        if (!FeloosApp.ready || !isEligibleForAppOpen()) return
        appOpenAd?.let { showAppOpenAd(it); return }
        if (appOpenLoading) return
        appOpenLoading = true
        AppOpenAd.load(
            this,
            BuildConfig.ADMOB_APP_OPEN_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : AppOpenAdLoadCallback() {
                override fun onAdLoaded(ad: AppOpenAd) {
                    appOpenLoading = false
                    appOpenAd = ad
                    if (isEligibleForAppOpen()) showAppOpenAd(ad)
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.w("FeloosAds", "App-open load failed: code=${error.code}, domain=${error.domain}, message=${error.message}, response=${error.responseInfo}")
                    appOpenLoading = false
                    appOpenAd = null
                }
            },
        )
    }

    private fun showAppOpenAd(ad: AppOpenAd) {
        if (!isEligibleForAppOpen()) return
        appOpenShowing = true
        appOpenAd = null
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdShowedFullScreenContent() {
                appOpenPrefs.edit().putLong("last_shown", System.currentTimeMillis()).apply()
            }
            override fun onAdDismissedFullScreenContent() {
                appOpenShowing = false
                maybeLoadOrShowAppOpenAd()
            }
            override fun onAdFailedToShowFullScreenContent(error: AdError) {
                android.util.Log.w("FeloosAds", "App-open show failed: code=${error.code}, message=${error.message}")
                appOpenShowing = false
                appOpenAd = null
            }
        }
        ad.show(this)
    }

    private fun setBannerAdVisibleOnUi(visible: Boolean) {
        if (!::bannerAdContainer.isInitialized) return
        bannerAdContainer.visibility = if (visible) View.VISIBLE else View.GONE
        if (!visible || bannerAdView != null || !FeloosApp.ready) return
        val adView = AdView(this).apply {
            adUnitId = BuildConfig.ADMOB_BANNER_AD_UNIT_ID
            setAdSize(AdSize.BANNER)
        }
        bannerAdView = adView
        bannerAdContainer.removeAllViews()
        bannerAdContainer.addView(adView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        adView.adListener = object : com.google.android.gms.ads.AdListener() {
            override fun onAdLoaded() { android.util.Log.d("FeloosAds", "Banner ad loaded") }
            override fun onAdFailedToLoad(error: LoadAdError) {
                android.util.Log.w("FeloosAds", "Banner load failed: code=${error.code}, domain=${error.domain}, message=${error.message}, response=${error.responseInfo}")
            }
        }
        adView.loadAd(AdRequest.Builder().build())
    }

    private fun preloadInterstitialAd() {
        if (!FeloosApp.ready || interstitialLoading || interstitialAd != null || isFinishing || isDestroyed) return
        interstitialLoading = true
        InterstitialAd.load(this, BuildConfig.ADMOB_INTERSTITIAL_AD_UNIT_ID, AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialLoading = false
                    interstitialAd = ad
                    android.util.Log.d("FeloosAds", "Interstitial ad loaded")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialLoading = false
                    interstitialAd = null
                    android.util.Log.w("FeloosAds", "Interstitial load failed: code=${error.code}, domain=${error.domain}, message=${error.message}, response=${error.responseInfo}")
                }
            })
    }

    private fun showInterstitialAd() {
        runOnUiThread {
            val now = System.currentTimeMillis()
            if (interstitialShowing || now - lastInterstitialShownAt < 10L * 60L * 1000L) return@runOnUiThread
            val ad = interstitialAd
            if (ad == null) {
                android.util.Log.d("FeloosAds", "Interstitial requested but not loaded")
                preloadInterstitialAd()
                return@runOnUiThread
            }
            interstitialAd = null
            interstitialShowing = true
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdShowedFullScreenContent() { lastInterstitialShownAt = System.currentTimeMillis() }
                override fun onAdDismissedFullScreenContent() {
                    interstitialShowing = false
                    preloadInterstitialAd()
                }
                override fun onAdFailedToShowFullScreenContent(error: AdError) {
                    interstitialShowing = false
                    android.util.Log.w("FeloosAds", "Interstitial show failed: code=${error.code}, message=${error.message}")
                    preloadInterstitialAd()
                }
            }
            ad.show(this)
        }
    }

    private fun setNativeAdVisibleOnUi(visible: Boolean) {
        if (!::nativeAdContainer.isInitialized) return
        nativeAdContainer.visibility = if (visible) View.VISIBLE else View.GONE
        if (!visible || nativeAd != null || nativeAdLoading) return
        nativeAdLoading = true
        com.google.android.gms.ads.AdLoader.Builder(this, BuildConfig.ADMOB_NATIVE_AD_UNIT_ID)
            .forNativeAd { ad ->
                android.util.Log.d("FeloosAds", "Native ad loaded")
                nativeAdLoading = false
                nativeAd?.destroy()
                nativeAd = ad
                renderNativeAd(ad)
            }
            .withAdListener(object : com.google.android.gms.ads.AdListener() {
                override fun onAdFailedToLoad(error: LoadAdError) {
                    android.util.Log.w("FeloosAds", "Native load failed: code=${error.code}, domain=${error.domain}, message=${error.message}, response=${error.responseInfo}")
                    nativeAdLoading = false
                }
            })
            .build()
            .loadAd(AdRequest.Builder().build())
    }

    private fun renderNativeAd(ad: NativeAd) {
        nativeAdContainer.removeAllViews()
        val adView = NativeAdView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
        }
        val label = TextView(this).apply {
            text = "إعلان"
            textSize = 11f
            setTextColor(android.graphics.Color.rgb(255, 209, 102))
        }
        val headline = TextView(this).apply {
            text = ad.headline.orEmpty()
            textSize = 15f
            setTextColor(android.graphics.Color.WHITE)
            setPadding(0, 4, 0, 4)
        }
        val body = TextView(this).apply {
            text = ad.body.orEmpty()
            textSize = 12f
            setTextColor(android.graphics.Color.LTGRAY)
            visibility = if (ad.body.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        val cta = Button(this).apply {
            text = ad.callToAction ?: "معرفة المزيد"
            isAllCaps = false
            visibility = if (ad.callToAction.isNullOrBlank()) View.GONE else View.VISIBLE
        }
        content.addView(label)
        content.addView(headline)
        content.addView(body)
        content.addView(cta)
        adView.addView(content)
        adView.headlineView = headline
        adView.bodyView = body
        adView.callToActionView = cta
        adView.setNativeAd(ad)
        nativeAdContainer.addView(adView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    private fun hush() {
        if (!::webView.isInitialized || isDestroyed) return
        try {
            webView.evaluateJavascript("window.feloosSilence&&window.feloosSilence()", null)
        } catch (_: Exception) {
        }
    }

    fun deliverReward(token: String, status: String) {
        deliver("window.__feloosReward", token, status)
    }

    private fun deliver(functionName: String, token: String, value: String) {
        if (!::webView.isInitialized || isDestroyed) return
        val js = functionName + "&&" + functionName + "(" +
            JSONObject.quote(token) + "," + JSONObject.quote(value) + ")"
        webView.post {
            if (!isDestroyed) webView.evaluateJavascript(js, null)
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun loadState(): String = prefs.getString(STATE_KEY, "").orEmpty()

        @JavascriptInterface
        fun saveState(json: String) {
            if (json.length > 500_000) return
            prefs.edit().putString(STATE_KEY, json).apply()
        }

        @JavascriptInterface
        fun preloadRewardedAd() {
            if (::ads.isInitialized) ads.preload()
        }

        @JavascriptInterface
        fun setNativeAdVisible(visible: Boolean) {
            runOnUiThread { setNativeAdVisibleOnUi(visible) }
        }

        @JavascriptInterface
        fun setBannerAdVisible(visible: Boolean) {
            runOnUiThread { setBannerAdVisibleOnUi(visible) }
        }

        @JavascriptInterface
        fun showInterstitialAd() {
            this@MainActivity.showInterstitialAd()
        }

        @JavascriptInterface
        fun showPrivacyOptions() {
            runOnUiThread { showPrivacyOptionsForm() }
        }

        @JavascriptInterface
        fun showRewardedAd(token: String) {
            if (::ads.isInitialized) ads.show(token)
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val clipboard = getSystemService(ClipboardManager::class.java)
                clipboard?.setPrimaryClip(ClipData.newPlainText("feloos", text))
            }
        }

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                leavingForShare = true
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(send, "مشاركة"))
            }
        }

        @JavascriptInterface
        fun finishApp() {
            runOnUiThread { finishAndRemoveTask() }
        }

    }

    companion object {
        private const val PREFS = "feloos"
        private const val STATE_KEY = "feloos.state.v1"
        private const val GAME_URL = "file:///android_asset/www/index.html"
        private const val BACK_JS =
            "(function(){if(window.feloosBack){window.feloosBack();return '1';}return '0';})()"
    }
}
