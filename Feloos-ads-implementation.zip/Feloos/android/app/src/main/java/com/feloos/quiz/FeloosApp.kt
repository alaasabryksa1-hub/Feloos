package com.feloos.quiz

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.ads.MobileAds

class FeloosApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Mobile Ads SDK initialization is delayed until the Activity completes UMP consent handling.
    }

    companion object {
        @Volatile
        var ready: Boolean = false
            private set
        @Volatile
        private var initializationStarted = false
        private val waiters = mutableListOf<() -> Unit>()

        fun initializeAds(context: Context) {
            synchronized(waiters) {
                if (ready || initializationStarted) return
                initializationStarted = true
            }
            Thread {
                MobileAds.initialize(context.applicationContext) {
                    val pending = synchronized(waiters) {
                        ready = true
                        waiters.toList().also { waiters.clear() }
                    }
                    val main = Handler(Looper.getMainLooper())
                    pending.forEach { block -> main.post(block) }
                }
            }.start()
        }

        fun whenReady(block: () -> Unit) {
            val runNow = synchronized(waiters) {
                if (ready) true else {
                    waiters += block
                    false
                }
            }
            if (runNow) Handler(Looper.getMainLooper()).post(block)
        }
    }
}
