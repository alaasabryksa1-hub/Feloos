(function () {
  if (window.__feloosBooted) return;
  window.__feloosBooted = true;
  var COST = 5;
  var FIFTY = 20;
  var AD_REWARD = 5;
  var AD_CAP = 40;
  var MIN_EGP = 200;
  var GEMS_PER_EGP = 10;
  var DAILY_MAX = 5;
  var KEY = "feloos.state.v1";
  var LEVELS = {
    easy: { name: "سهل", time: 30, gems: 1 },
    medium: { name: "متوسط", time: 20, gems: 2 },
    hard: { name: "صعب", time: 15, gems: 3 },
  };
  var LETTERS = ["أ", "ب", "ج", "د"];
  var METHODS = ["فودافون كاش", "اتصالات كاش", "وي باي", "أورانج كاش", "إنستا باي"];
  var QUESTIONS = window.QUESTIONS || [];

  var state;
  var screen = "login";
  var backTo = "home";
  var level = "easy";
  var daily = false;
  var reveal = null;
  var picked = null;
  var correct = null;
  var hidden = [];
  var gain = 0;
  var adLock = false;
  var adTimer = null;
  var tick = null;
  var toastTimer = null;
  var coinResolve = null;
  var busy = false;
  var beepedFor = null;
  var introResolve = null;

  function asset(path) {
    if (location.protocol === "file:") return path;
    var pathName = location.pathname || "/";
    var prefixed = pathName.match(/^(\/hds-[a-z0-9]+-\d+-[a-z0-9]+)(?:\/|$)/i);
    if (prefixed) return prefixed[1] + "/" + path;
    return "/" + path;
  }

  var audible = true;
  var liveSounds = [];

  function makeAudio(path) {
    try {
      var audio = new Audio(asset(path));
      audio.preload = "auto";
      audio.loop = false;
      return audio;
    } catch (e) {
      return null;
    }
  }

  var sfx = {
    tap: makeAudio("sfx/tap.wav"),
    wallet: makeAudio("sfx/wallet.wav"),
    tick: makeAudio("sfx/tick.wav"),
    urgent: makeAudio("sfx/urgent.wav"),
    ok: makeAudio("sfx/correct.wav"),
    bad: makeAudio("sfx/wrong.wav"),
    coins: makeAudio("sfx/coins.wav"),
  };

  function playSfx(name) {
    if (!audible) return;
    var audio = sfx[name];
    if (!audio) return;
    try {
      // Never overlap duplicate instances of the same effect (especially timer ticks).
      liveSounds.slice().forEach(function (active) {
        if (active.__feloosSoundName === name) {
          try { active.pause(); active.currentTime = 0; } catch (e) {}
          var oldIndex = liveSounds.indexOf(active);
          if (oldIndex >= 0) liveSounds.splice(oldIndex, 1);
        }
      });
      var node = audio.cloneNode();
      node.__feloosSoundName = name;
      node.loop = false;
      node.volume = name === "tick" ? 0.28 : name === "urgent" ? 0.4 : name === "tap" ? 0.45 : 0.72;
      liveSounds.push(node);
      node.addEventListener("ended", function () {
        var i = liveSounds.indexOf(node);
        if (i >= 0) liveSounds.splice(i, 1);
      });
      var playing = node.play();
      if (playing && playing.catch) playing.catch(function () {});
    } catch (e) {}
  }

  function stopSounds() {
    clearInterval(tick);
    tick = null;
    liveSounds.forEach(function (node) {
      try {
        node.pause();
        node.currentTime = 0;
      } catch (e) {}
    });
    liveSounds = [];
  }

  function freezeClock() {
    if (state && state.open && !state.open.answered && state.open.deadline) {
      state.open.remainMs = Math.max(0, state.open.deadline - Date.now());
      save();
    }
    stopSounds();
  }

  function thawClock() {
    if (!state || !state.open || state.open.answered) return;
    if (typeof state.open.remainMs === "number") {
      state.open.deadline = Date.now() + state.open.remainMs;
      delete state.open.remainMs;
      save();
    }
  }

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      if (c === "&") return "&" + "amp;";
      if (c === "<") return "&" + "lt;";
      if (c === ">") return "&" + "gt;";
      if (c === '"') return "&" + "quot;";
      return "&" + "#39;";
    });
  }

  function today() {
    try {
      return new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Cairo" }).format(new Date());
    } catch (e) {
      var d = new Date();
      return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate());
    }
  }

  function pad(n) {
    return (n < 10 ? "0" : "") + n;
  }

  function makeCode() {
    var alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    var bytes = new Uint8Array(6);
    if (window.crypto && crypto.getRandomValues) crypto.getRandomValues(bytes);
    else for (var i = 0; i < 6; i++) bytes[i] = Math.floor(Math.random() * 256);
    var code = "";
    for (var j = 0; j < 6; j++) code += alphabet[bytes[j] % alphabet.length];
    return code;
  }

  function fresh() {
    return {
      v: 1,
      updatedAt: Date.now(),
      onboarded: false,
      signedOut: false,
      adultOk: false,
      welcomed: false,
      name: "",
      coins: 200,
      gems: 0,
      best: 0,
      refCode: makeCode(),
      inviteRewardClaimed: false,
      dailyDate: "",
      dailyCount: 0,
      adsDate: "",
      adsCount: 0,
      seen: { easy: [], medium: [], hard: [] },
      round: { gems: 0, correct: 0, total: 0 },
      open: null,
      withdrawals: [],
      nextId: 1,
    };
  }

  function nativeLoad() {
    try {
      if (window.FeloosNative && FeloosNative.loadState) return FeloosNative.loadState() || "";
    } catch (e) {}
    return "";
  }

  function parseState(raw) {
    if (!raw) return null;
    try {
      var data = JSON.parse(raw);
      if (!data || data.v !== 1) return null;
      return data;
    } catch (e) {
      return null;
    }
  }

  function load() {
    var local = "";
    try {
      local = localStorage.getItem(KEY) || "";
    } catch (e) {}
    var a = parseState(local);
    var b = parseState(nativeLoad());
    if (a && b) return a.updatedAt >= b.updatedAt ? a : b;
    return a || b || fresh();
  }

  function processMatureWithdrawals() {
    if (!state || !Array.isArray(state.withdrawals)) return false;
    var now = Date.now();
    var changed = false;
    state.withdrawals.forEach(function (row) {
      if (!row || row.status !== "قيد المراجعة" || !row.createdAt) return;
      var created = Date.parse(row.createdAt);
      if (!Number.isFinite(created) || now - created < 24 * 60 * 60 * 1000) return;
      // Automatic local status after 24 hours, per the app owner's requested workflow.
      // This is not proof of payment and is not secure without a trusted backend.
      row.status = "تم التحويل بنجاح";
      row.completedAt = new Date(now).toISOString();
      row.autoCompleted = true;
      var reserved = Math.max(0, Number(row.reservedGems) || 0);
      state.gems = Math.max(0, Number(state.gems) - reserved);
      row.reservedGems = 0;
      changed = true;
    });
    return changed;
  }

  function save() {
    state.updatedAt = Date.now();
    var json = JSON.stringify(state);
    try {
      localStorage.setItem(KEY, json);
    } catch (e) {}
    try {
      if (window.FeloosNative && FeloosNative.saveState) FeloosNative.saveState(json);
    } catch (e2) {}
  }

  function adsUsed() {
    return state.adsDate === today() ? state.adsCount : 0;
  }
  function adsLeft() {
    return Math.max(0, AD_CAP - adsUsed());
  }
  function dailyUsed() {
    return state.dailyDate === today() ? state.dailyCount : 0;
  }
  function dailyLeft() {
    return Math.max(0, DAILY_MAX - dailyUsed());
  }
  function reservedGems() {
    return (Array.isArray(state.withdrawals) ? state.withdrawals : []).reduce(function (sum, row) {
      return sum + (row && row.status === "قيد المراجعة" ? Math.max(0, Number(row.reservedGems) || 0) : 0);
    }, 0);
  }

  function availableGems() {
    return Math.max(0, state.gems - reservedGems());
  }

  function egp() {
    return Math.floor(availableGems() / GEMS_PER_EGP);
  }

  function showToast(msg) {
    var el = document.getElementById("toast");
    el.textContent = msg;
    el.hidden = !msg;
    clearTimeout(toastTimer);
    if (msg) toastTimer = setTimeout(function () { el.hidden = true; }, 2800);
  }

  function $(id) {
    return document.getElementById(id);
  }

  function render() {
    if (processMatureWithdrawals()) save();
    $("app").innerHTML = '<div class="phone">' + header() + body() + "</div>";
    // The native-format ad is non-rewarded and is shown only on ordinary content screens.
    try {
      if (window.FeloosNative && typeof FeloosNative.setNativeAdVisible === "function") {
        FeloosNative.setNativeAdVisible(screen === "home" || screen === "wallet");
      }
    } catch (e) {}
    if (screen === "quiz") startClock();
    else clearInterval(tick);
  }

  function header() {
    if (screen === "login" || screen === "privacy" || screen === "terms") return "";
    var left = screen === "home"
      ? '<span class="gold" style="font-size:1.15rem;font-weight:800">من سيربح الفلوس</span>'
      : '<button class="btn" style="width:auto;padding:.55rem .8rem" data-act="back" type="button" aria-label="رجوع">رجوع</button>';
    return '<header class="row" style="margin-bottom:1rem">' + left +
      '<button class="btn" style="width:auto" data-act="wallet" type="button">' + state.coins + " عملة · " + state.gems + " جوهرة</button></header>";
  }

  function body() {
    if (screen === "login") return loginView();
    if (screen === "home") return homeView();
    if (screen === "levels") return levelsView();
    if (screen === "quiz") return quizView();
    if (screen === "result") return resultView();
    if (screen === "wallet") return walletView();
    if (screen === "withdraw") return withdrawView();
    if (screen === "invite") return inviteView();
    if (screen === "privacy") return legal("الخصوصية", privacyText(), backTo);
    if (screen === "terms") return legal("شروط اللعب", termsText(), backTo);
    return homeView();
  }

  function loginView() {
    var back = state.onboarded ? "رجوع لحسابي" : "دخول وحفظ الحساب";
    return '<main class="stack center">' +
      '<img class="logo" src="' + asset('logo.jpg') + '" alt="">' +
      '<h1 class="display gold">من سيربح<br>الفلوس</h1>' +
      '<label>اسمك في اللعبة<input id="pname" maxlength="24" value="' + esc(state.name) + '" placeholder="لاعب"></label>' +
      '<label class="check"><input id="age" type="checkbox"' + (state.adultOk ? " checked" : "") + '> أنا 16 سنة أو أكثر</label>' +
      '<button class="btn gold" data-act="enter" type="button">' + back + "</button>" +
      '<p><button class="linkish" data-act="terms" type="button">الشروط</button> · <button class="linkish" data-act="privacy" type="button">الخصوصية</button></p>' +
      "</main>";
  }

  function homeView() {
    return '<main class="stack center" style="flex:1">' +
      '<img class="logo" src="' + asset('logo.jpg') + '" alt="">' +
      '<h1 class="display gold">من سيربح<br>الفلوس</h1>' +
      '<p class="muted">أهلاً ' + esc(state.name || "لاعب") + ". جاوب صح، اجمع جواهر، واطلب سحبها بعد المراجعة.</p>" +
      '<button class="btn gold" data-act="levels" type="button">ابدأ اللعب</button>' +
      '<button class="btn" data-act="daily" type="button"' + (dailyLeft() <= 0 ? " disabled" : "") + ">" +
      (dailyLeft() <= 0 ? "أنهيت تحدي اليوم" : "التحدي اليومي (" + dailyLeft() + " أسئلة ببلاش)") + "</button>" +
      '<div class="grid2"><button class="tile" data-act="wallet" type="button">المحفظة</button><button class="tile" data-act="invite" type="button">ادعُ صديقاً</button></div>' +
      '<button class="btn" data-act="watch" type="button">شاهد إعلاناً واربح 5 عملات</button>' +
      '<p class="muted">متبقي إعلانات اليوم: ' + adsLeft() + "</p>" +
      '<p class="muted" style="margin-top:auto">أفضل جولة: ' + state.best + " جوهرة</p></main>";
  }

  function levelsView() {
    var html = '<main class="stack"><h2 class="center display" style="font-size:1.8rem">اختر المستوى</h2>' +
      '<p class="muted center">قبل المستوى يظهر إعلان مكافأة وتقدر تتخطاه. السؤال بـ 5 عملات، ومن غير عملات لازم الإعلان يكتمل.</p>';
    ["easy", "medium", "hard"].forEach(function (key) {
      var meta = LEVELS[key];
      html += '<button class="card level" data-act="start" data-level="' + key + '" type="button"><span><b style="font-size:1.3rem">' +
        meta.name + '</b><br><span class="muted">' + meta.time + " ثانية · 5 عملات</span></span><b style=\"color:var(--gem)\">+" +
        meta.gems + " جوهرة</b></button>";
    });
    return html + "</main>";
  }

  function quizView() {
    var open = state.open;
    if (!open) return '<main class="center"><p>مفيش سؤال مفتوح</p><button class="btn gold" data-act="home" type="button">الرئيسية</button></main>';
    var secs = Math.max(0, Math.ceil((open.deadline - Date.now()) / 1000));
    var questionNumber = state.round.total + (open.answered ? 0 : 1);
    var html = '<main class="stack" style="flex:1"><div class="row"><span class="muted">السؤال ' + questionNumber +
      (open.daily ? " / 5" : "") + '</span><b id="clock" class="gold">' + secs + ' ث</b></div>' +
      '<div class="bar"><span id="bar" style="width:' + Math.max(0, Math.min(100, (secs / open.time) * 100)) + '%"></span></div>' +
      '<div class="card qbox">' + esc(open.q) + "</div>";
    open.a.forEach(function (option, index) {
      var cls = "choice";
      if (hidden.indexOf(index) >= 0 && reveal === null) cls += " hide";
      if (reveal === null && picked === index) cls += " mark";
      if (reveal !== null && index === reveal) cls += " ok";
      else if (reveal !== null && index === picked) cls += " bad";
      html += '<button class="' + cls + '" data-act="answer" data-i="' + index + '" type="button"' +
        (reveal !== null || hidden.indexOf(index) >= 0 ? " disabled" : "") + "><span class=\"ltr\">" +
        LETTERS[index] + ":</span> " + esc(option) + "</button>";
    });
    html += '<div style="margin-top:auto">';
    if (reveal === null) {
      html += '<button class="btn" data-act="fifty" type="button"' + (state.coins < FIFTY || hidden.length ? " disabled" : "") + ">حذف إجابتين (20 عملة)</button>";
    } else {
      var msg = correct ? "إجابة صحيحة +" + gain + " جوهرة" : picked === -1 ? "انتهى الوقت" : "إجابة خاطئة";
      var nextLabel = open.daily && dailyLeft() <= 0 ? "عرض النتيجة" : open.daily ? "السؤال التالي" : "السؤال التالي (5 عملات)";
      html += '<p class="center"><b>' + msg + '</b></p><button class="btn gold" data-act="next" type="button">' + nextLabel + "</button>";
    }
    return html + "</div></main>";
  }

  function resultView() {
    return '<main class="stack center" style="flex:1;justify-content:center"><h2 class="display">انتهت الجولة</h2>' +
      '<p class="muted">أجبت ' + state.round.correct + " إجابة صحيحة من " + state.round.total + "</p>" +
      '<p class="display" style="color:var(--gem)">+' + state.round.gems + " جوهرة</p>" +
      '<button class="btn gold" data-act="levels" type="button">العب مرة أخرى</button>' +
      '<button class="btn" data-act="wallet" type="button">المحفظة</button></main>';
  }

  function walletView() {
    var rows = state.withdrawals.slice().reverse().map(function (row) {
      return '<div class="card"><b>' + row.amount + " ج.م · " + esc(row.method) + "</b><br><span class=\"muted\">" +
        esc(row.phone) + " · " + esc(row.status) + "</span></div>";
    }).join("") || '<p class="muted">لا توجد طلبات بعد</p>';
    return '<main class="stack"><h2 class="center display" style="font-size:1.8rem">المحفظة</h2>' +
      '<div class="wallet-hero"><div>رصيدك القابل للسحب</div><div class="display">' + egp() + ' ج.م</div><div>' + state.gems + " جوهرة · كل 10 جواهر = 1 جنيه</div></div>" +
      '<div class="grid2"><div class="card"><span class="muted">العملات</span><div class="gold" style="font-size:1.6rem;font-weight:800">' + state.coins +
      '</div></div><div class="card"><span class="muted">الجواهر</span><div style="color:var(--gem);font-size:1.6rem;font-weight:800">' + state.gems + "</div></div></div>" +
      '<p class="muted">العملات للعب فقط ولا تتحول لفلوس. الجواهر من الإجابات الصحيحة فقط. حالة طلب السحب تتغير تلقائيًا بعد 24 ساعة على هذا الجهاز.</p>' +
      '<button class="btn gold" data-act="withdraw" type="button">سحب الأرباح</button>' +
      '<button class="btn" data-act="watch" type="button">شاهد إعلاناً واربح 5 عملات</button>' +
      "<h3>طلبات السحب</h3>" + rows +
      '<p class="center"><button class="linkish" data-act="privacy" type="button">الخصوصية</button> · <button class="linkish" data-act="terms" type="button">الشروط</button></p>' +
      '<button class="linkish" data-act="signout" type="button">تسجيل الخروج</button></main>';
  }

  function withdrawView() {
    return '<main class="stack"><h2 class="center display" style="font-size:1.8rem">سحب الأرباح</h2>' +
      '<p class="muted center">المتاح للسحب ' + egp() + " ج.م من " + availableGems() + " جوهرة متاحة. الحد الأدنى 200 جنيه. الطلب بيتبعت للمراجعة والتحويل اليدوي.</p>" +
      '<label>المبلغ (جنيه)<input id="amount" inputmode="numeric" value="200"></label>' +
      '<label>الطريقة<select id="method">' + METHODS.map(function (m) { return "<option>" + m + "</option>"; }).join("") + "</select></label>" +
      '<label>رقم المحفظة<input id="phone" inputmode="tel" dir="ltr" placeholder="01xxxxxxxxx" maxlength="11"></label>' +
      '<label>الاسم على المحفظة<input id="holder" maxlength="80"></label>' +
      '<label class="check"><input id="over18" type="checkbox"> أنا 18 سنة أو أكثر</label>' +
      '<button class="btn gold" data-act="send-withdraw" type="button">تأكيد السحب</button></main>';
  }

  function inviteView() {
    var share = "العب معايا «من سيربح الفلوس» واختبر معلوماتك.";
    return '<main class="stack center"><h2 class="display" style="font-size:1.8rem">ادعُ أصدقاءك</h2>' +
      '<p class="muted">شارك اللعبة. كودك ظاهر هنا عشان النسخة المتصلة بالحساب.</p>' +
      '<div class="card" dir="ltr" style="font-size:1.8rem;letter-spacing:.2rem;color:var(--gold);font-weight:800">' + esc(state.refCode) + "</div>" +
      '<p class="muted">عند مشاركة الدعوة لأول مرة تحصل على 50 عملة لعب مرة واحدة على هذا الجهاز.</p>' +
      '<button class="btn gold" data-act="share" data-text="' + esc(share) + '" type="button">شارك اللعبة واربح 50 عملة</button>' +
      '<button class="btn" data-act="copy" data-text="' + esc(state.refCode) + '" type="button">نسخ الكود</button></main>';
  }


  function legal(title, text, ret) {
    return '<main class="stack"><button class="linkish" data-act="legal-back" data-to="' + ret + '" type="button">رجوع</button><h1 class="gold">' +
      title + "</h1>" + text + "</main>";
  }

  function privacyText() {
    return "<p>من سيربح الفلوس بيحفظ بيانات اللعب على جهازك: الاسم، رصيد العملات والجواهر، والأسئلة اللي شفتها، عشان تفضل داخل من غير تسجيل كل مرة.</p>" +
      "<p>رقم الموبايل والاسم على المحفظة بيتسجلوا فقط لما تطلب سحب، وبيتبعتوا لإيميل الإدارة عشان تحوّل المبلغ يدويًا. مش بنخزّن بيانات بطاقة.</p>" +
      "<p>العملات رصيد لعب فقط ومش بتتحول لفلوس. الجواهر من الإجابة الصحيحة بس. السحب مش فوري وممكن يترفض، ومشاهدة الإعلان متديش فلوس حقيقية.</p>" +
      "<p>إعلان المكافأة إعلان بيني مقابل مكافأة من Google AdMob. قبل ما يظهر بنوضّح إن المكافأة 5 عملات لعب، وتقدر تتخطاه. العملات بتتضاف مرة واحدة بس لما Google تأكد إن الإعلان خلّص. قفل الإعلان أو الضغط على الزر لوحده مش بيدي مكافأة. Google ممكن تعالج بيانات الإعلان حسب سياستها.</p>" +
      "<p>اللعبة لسن 16 فأكثر، وطلب السحب لمن يبلغ 18 سنة.</p>" +
      '<p><button class="linkish" data-act="privacy-options" type="button">إعدادات خصوصية الإعلانات</button></p>';
  }

  function termsText() {
    return "<p>اللعبة مسابقة معلومات. مفيش حظ ولا رهان ولا قمار. اللعب من سن 16، وطلب السحب من سن 18.</p>" +
      "<p>مشاهدة إعلان المكافأة لحد ما Google تأكد المكافأة بتدي 5 عملات لعب فقط، مش جنيه ولا جواهر. السؤال العادي بـ 5 عملات. من غير عملات السؤال المدفوع مش هيبدأ، ولو الإعلان مش متاح اللعبة نفسها مش بتقف.</p>" +
      "<p>قبل الإعلان فيه شاشة بتوضح المكافأة، وتقدر تتخطى الإعلان من غير ما تاخد عملات. الإعلان بيتقترح في بداية كل مستوى، وبعد كل 10 أسئلة، ولما تفتح المحفظة. الحد اليومي 40 مكافأة إعلان.</p>" +
      "<p>كل 10 جواهر = 1 جنيه تقديراً. أقل سحب 200 جنيه، تحويل يدوي بعد المراجعة، ومش مضمون.</p>";
  }

  function startClock() {
    clearInterval(tick);
    // The countdown must continue even when sounds are muted.
    tick = setInterval(function () {
      if (screen !== "quiz" || !state.open || reveal !== null) return;
      var left = Math.max(0, Math.ceil((state.open.deadline - Date.now()) / 1000));
      var clock = $("clock");
      var bar = $("bar");
      if (clock) clock.textContent = left + " ث";
      if (bar) bar.style.width = Math.max(0, Math.min(100, (left / state.open.time) * 100)) + "%";
      if (left <= 0) {
        clearInterval(tick);
        answer(-1);
        return;
      }
      if (beepedFor !== left) {
        beepedFor = left;
        playSfx(left <= 5 ? "urgent" : "tick");
      }
    }, 250);
  }

  function hideAd() {
    clearTimeout(adTimer);
    var ad = $("ad");
    if (ad) ad.hidden = true;
    if (introResolve) closeIntro("skip");
  }

  function showAdIntro(title) {
    return new Promise(function (resolve) {
      introResolve = resolve;
      var heading = $("ad-title");
      if (heading) heading.textContent = title;
      var note = $("ad-status");
      if (note) {
        note.textContent = window.FeloosNative && typeof FeloosNative.showRewardedAd === "function"
          ? "الإعلان من Google. المكافأة تتأكد من الإعلان نفسه، مش من الزر."
          : "في المعاينة مفيش إعلان Google، فالمكافأة مش هتتضاف لو ضغطت شاهد.";
      }
      $("ad").hidden = false;
    });
  }

  function closeIntro(choice) {
    var fn = introResolve;
    introResolve = null;
    var ad = $("ad");
    if (ad) ad.hidden = true;
    if (fn) fn(choice === "watch" ? "watch" : "skip");
  }

  function nativeAd() {
    return new Promise(function (resolve) {
      if (!window.FeloosNative || typeof FeloosNative.showRewardedAd !== "function") {
        resolve("none");
        return;
      }
      var token = (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : (String(Date.now()) + "-" + Math.random().toString(36).slice(2));
      var done = false;
      window.__feloosReward = function (got, status) {
        if (done || got !== token) return;
        done = true;
        resolve({ status: status || "unavailable", token: token });
      };
      try {
        FeloosNative.showRewardedAd(token);
      } catch (e) {
        resolve("unavailable");
        return;
      }
      setTimeout(function () {
        if (!done) {
          done = true;
          resolve("unavailable");
        }
      }, 180000);
    });
  }

  function preloadNativeAd() {
    try {
      if (window.FeloosNative && FeloosNative.preloadRewardedAd) FeloosNative.preloadRewardedAd();
    } catch (e) {}
  }

  function playAd(title) {
    if (adLock) return Promise.resolve("busy");
    adLock = true;
    return (async function () {
      try {
        if (adsUsed() >= AD_CAP) {
          showToast("وصلت للحد اليومي للإعلانات، ارجع بكرة");
          return "limit";
        }
        preloadNativeAd();
        var choice = await showAdIntro(title);
        if (choice !== "watch") {
          showToast("تم تخطي الإعلان، من غير عملات");
          return "skip";
        }
        if (!window.FeloosNative || typeof FeloosNative.showRewardedAd !== "function") {
          showToast("الإعلان مش متاح دلوقتي. مفيش مكافأة من غير إعلان Google، واللعبة هتكمل.");
          return "unavailable";
        }
        showToast("جاري فتح الإعلان...");
        var adResult = await nativeAd();
        var native = typeof adResult === "string" ? adResult : adResult.status;
        preloadNativeAd();
        if (native === "reward") {
          var rewardToken = typeof adResult === "object" ? adResult.token : "";
          state.rewardedAdTokens = Array.isArray(state.rewardedAdTokens) ? state.rewardedAdTokens : [];
          if (!rewardToken || state.rewardedAdTokens.indexOf(rewardToken) !== -1) {
            showToast("المكافأة دي اتسجلت قبل كده");
            return "duplicate";
          }
          state.rewardedAdTokens.push(rewardToken);
          if (state.rewardedAdTokens.length > 500) state.rewardedAdTokens = state.rewardedAdTokens.slice(-500);
          var used = state.adsDate === today() ? state.adsCount : 0;
          state.adsDate = today();
          state.adsCount = used + 1;
          state.coins += AD_REWARD;
          save();
          playSfx("coins");
          showToast("حصلت على " + AD_REWARD + " عملات للعب");
          if (screen !== "quiz") render();
          return "ok";
        }
        if (native === "dismiss") {
          showToast("الإعلان اتقفل قبل المكافأة، مفيش عملات");
          return "dismiss";
        }
        showToast("الإعلان مش متاح دلوقتي. جرّب بعد شوية، واللعبة هتكمل.");
        return "unavailable";
      } finally {
        adLock = false;
        var ad = $("ad");
        if (ad) ad.hidden = true;
        introResolve = null;
      }
    })();
  }

  function askForCoins() {
    return new Promise(function (resolve) {
      coinResolve = resolve;
      $("coins").hidden = false;
    });
  }

  function closeCoins(yes) {
    $("coins").hidden = true;
    var fn = coinResolve;
    coinResolve = null;
    if (fn) fn(yes);
  }

  async function ensureCoins() {
    var guard = 0;
    while (state.coins < COST && guard < 6) {
      guard += 1;
      var yes = await askForCoins();
      if (!yes) return false;
      var result = await playAd("عملاتك خلصت — شاهد الإعلان");
      if (result !== "ok") return false;
    }
    return state.coins >= COST;
  }

  function pickQuestion(lv) {
    var seen = state.seen[lv] || [];
    var pool = QUESTIONS.filter(function (item) { return item.level === lv && seen.indexOf(item.id) < 0; });
    if (!pool.length) {
      state.seen[lv] = [];
      pool = QUESTIONS.filter(function (item) { return item.level === lv; });
    }
    if (!pool.length) return null;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  async function openQuestion(nextLevel, isDaily, newRound) {
    var lv = isDaily ? "medium" : nextLevel;
    if (isDaily) {
      var used = dailyUsed();
      if (used >= DAILY_MAX) {
        showToast("أنهيت تحدي اليوم");
        screen = "home";
        render();
        return;
      }
    } else if (state.coins < COST) {
      var ok = await ensureCoins();
      if (!ok) return;
    }
    var chosen = pickQuestion(lv);
    if (!chosen) {
      showToast("مفيش أسئلة متاحة دلوقتي");
      return;
    }
    state.seen[lv] = state.seen[lv] || [];
    if (state.seen[lv].indexOf(chosen.id) < 0) state.seen[lv].push(chosen.id);
    if (isDaily) {
      var count = dailyUsed();
      state.dailyDate = today();
      state.dailyCount = count + 1;
    } else {
      if (state.coins < COST) {
        showToast("عملاتك غير كافية");
        return;
      }
      state.coins -= COST;
    }
    if (newRound) state.round = { gems: 0, correct: 0, total: 0 };
    var meta = LEVELS[lv];
    state.open = {
      id: chosen.id,
      q: chosen.q,
      a: chosen.a,
      c: chosen.c,
      time: meta.time,
      level: lv,
      daily: isDaily,
      hidden: [],
      deadline: Date.now() + meta.time * 1000,
    };
    save();
    reveal = null;
    picked = null;
    correct = null;
    hidden = [];
    gain = 0;
    beepedFor = null;
    level = lv;
    daily = isDaily;
    screen = "quiz";
    render();
  }

  async function startLevel(next) {
    if (busy || adLock) return;
    busy = true;
    try {
      var isDaily = next === "daily";
      level = isDaily ? "medium" : next;
      daily = isDaily;
      await playAd(isDaily ? "إعلان قبل التحدي اليومي" : "إعلان بداية المستوى");
      if (!isDaily && !(await ensureCoins())) return;
      await openQuestion(level, isDaily, true);
    } finally {
      busy = false;
    }
  }

  function answer(choice) {
    var open = state.open;
    if (!open || open.answered || reveal !== null) return;
    var isCorrect = choice === open.c;
    var got = isCorrect ? LEVELS[open.level].gems : 0;
    state.round.total += 1;
    state.round.gems += got;
    state.round.correct += isCorrect ? 1 : 0;
    state.gems += got;
    if (state.round.gems > state.best) state.best = state.round.gems;
    playSfx(isCorrect ? "ok" : "bad");
    open.answered = true;
    open.picked = choice;
    save();
    reveal = open.c;
    picked = choice;
    correct = isCorrect;
    gain = got;
    screen = "quiz";
    render();
  }

  async function nextQuestion() {
    if (daily && dailyLeft() <= 0) {
      screen = "result";
      render();
      return;
    }
    if (state.round.total > 0 && state.round.total % 10 === 0) {
      await playAd("إعلان بعد عشرة أسئلة");
    }
    if (!daily && !(await ensureCoins())) return;
    await openQuestion(level, daily, false);
  }

  function fifty() {
    if (!state.open || state.open.answered || reveal !== null || hidden.length) return;
    if (state.coins < FIFTY) {
      showToast("عملاتك لا تكفي للمساعدة");
      return;
    }
    var wrong = [0, 1, 2, 3].filter(function (i) { return i !== state.open.c; });
    wrong.sort(function () { return Math.random() - 0.5; });
    hidden = wrong.slice(0, 2);
    state.coins -= FIFTY;
    state.open.hidden = hidden.slice();
    save();
    render();
  }

  function openWallet() {
    // Opening the wallet is not a rewarded-ad event.
    screen = "wallet";
    render();
  }


  async function sendWithdraw() {
    var amount = parseInt($("amount").value, 10);
    var method = $("method").value;
    var phone = ($("phone").value || "").replace(/[^\d]/g, "");
    var holder = ($("holder").value || "").trim();
    if (!$("over18").checked) {
      showToast("طلب السحب من سن 18");
      return;
    }
    if (!amount || amount < MIN_EGP) { showToast("الحد الأدنى للسحب 200 جنيه"); return; }
    if (!/^01[0125]\d{8}$/.test(phone)) { showToast("رقم الهاتف غير صحيح"); return; }
    if (holder.length < 3) { showToast("اكتب الاسم الثلاثي على المحفظة"); return; }
    var cost = amount * GEMS_PER_EGP;
    if (availableGems() < cost) { showToast("رصيد الجواهر المتاح غير كافٍ أو محجوز في طلب سابق"); return; }

    var button = document.querySelector('[data-act="send-withdraw"]');
    if (button) button.disabled = true;
    var requestId = "FLS-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2, 8).toUpperCase();
    var seenTotal = 0;
    try {
      var seen = state.seen || {};
      ["easy", "medium", "hard"].forEach(function (k) { seenTotal += Array.isArray(seen[k]) ? seen[k].length : 0; });
    } catch (_) {}
    var answered = Number(state.round && state.round.total || 0);
    var correctCount = Number(state.round && state.round.correct || 0);
    var wrongCount = Math.max(0, answered - correctCount);
    try {
      var response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          service_id: "service_feloos",
          template_id: "template_re4e9yd",
          user_id: "e_vONHSRYEdJp6rWJ",
          template_params: {
            request_id: requestId,
            player_name: state.name || "لاعب",
            amount: String(amount),
            payment_method: method,
            phone: phone,
            account_holder: holder,
            snapshot_gems: String(state.gems),
            snapshot_questions_seen: String(seenTotal),
            snapshot_answered: String(answered),
            snapshot_correct: String(correctCount),
            snapshot_wrong: String(wrongCount),
            title: "طلب سحب جديد - لعبة فِلوس"
          }
        })
      });
      if (!response.ok) {
        var errText = await response.text().catch(function () { return ""; });
        throw new Error("EmailJS " + response.status + (errText ? ": " + errText.slice(0, 120) : ""));
      }
      state.withdrawals.push({ id: requestId, amount: amount, reservedGems: cost, method: method, phone: phone, holder: holder, status: "قيد المراجعة", createdAt: new Date().toISOString(), snapshotAnswered: answered, snapshotCorrect: correctCount, snapshotWrong: wrongCount });
      save();
      screen = "wallet";
      render();
      showToast("تم استلام طلب السحب. ستتغير حالته تلقائيًا بعد 24 ساعة.");
    } catch (error) {
      showToast("فشل إرسال الطلب. لم يتم تسجيله: " + (error.message || "خطأ اتصال"));
    } finally {
      if (button) button.disabled = false;
    }
  }

  async function sha256(text) {
    var buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text.trim()));
    return Array.prototype.map.call(new Uint8Array(buf), function (b) {
      return ("0" + b.toString(16)).slice(-2);
    }).join("");
  }

  function goLegal(which) {
    backTo = screen === "wallet" ? "wallet" : "login";
    screen = which;
    render();
  }

  function resumeIfNeeded() {
    if (!state.open) return;
    hidden = state.open.hidden || [];
    level = state.open.level || "easy";
    daily = !!state.open.daily;
    screen = "quiz";
    if (state.open.answered) {
      reveal = state.open.c;
      picked = typeof state.open.picked === "number" ? state.open.picked : null;
      correct = picked === reveal;
      gain = correct ? LEVELS[level].gems : 0;
      return;
    }
    thawClock();
    reveal = null;
    picked = null;
    correct = null;
    if (Date.now() >= state.open.deadline) answer(-1);
  }

  function uiSound(act) {
    if (act === "answer" || act === "enter") return;
    playSfx(act === "wallet" ? "wallet" : "tap");
  }

  document.addEventListener("click", function (event) {
    var el = event.target.closest("[data-act]");
    if (!el || el.disabled) return;
    var act = el.getAttribute("data-act");
    uiSound(act);
    if (act === "coins-yes") return closeCoins(true);
    if (act === "coins-no") return closeCoins(false);
    if (act === "ad-watch") return closeIntro("watch");
    if (act === "ad-skip") return closeIntro("skip");
    if (adLock) return;
    if (act === "enter") {
      var age = $("age");
      if (!age || !age.checked) {
        showToast("اللعبة من سن 16 سنة");
        return;
      }
      var name = (($("pname") && $("pname").value) || "").trim().slice(0, 24);
      state.name = name || state.name || "لاعب";
      state.adultOk = true;
      state.onboarded = true;
      state.signedOut = false;
      var first = !state.welcomed;
      state.welcomed = true;
      save();
      screen = "home";
      render();
      if (first) {
        playSfx("coins");
        showToast("أهلاً! معاك 200 عملة هدية");
      } else playSfx("tap");
      return;
    }
    if (act === "back") {
      window.feloosBack();
      return;
    }
    if (act === "home") {
      screen = "home";
      render();
      return;
    }
    if (act === "levels") {
      screen = "levels";
      render();
      return;
    }
    if (act === "daily") return startLevel("daily");
    if (act === "start") return startLevel(el.getAttribute("data-level"));
    if (act === "watch") return playAd("إعلان مكافأة");
    if (act === "wallet") return openWallet();
    if (act === "invite") {
      screen = "invite";
      render();
      return;
    }
    if (act === "withdraw") {
      screen = "withdraw";
      render();
      return;
    }
    if (act === "answer") return answer(Number(el.getAttribute("data-i")));
    if (act === "next") return nextQuestion();
    if (act === "fifty") return fifty();
    if (act === "send-withdraw") return sendWithdraw();
    if (act === "privacy") return goLegal("privacy");
    if (act === "privacy-options") {
      if (window.FeloosNative && typeof FeloosNative.showPrivacyOptions === "function") FeloosNative.showPrivacyOptions();
      else showToast("إعدادات الخصوصية متاحة داخل تطبيق أندرويد");
      return;
    }
    if (act === "terms") return goLegal("terms");
    if (act === "legal-back") {
      screen = el.getAttribute("data-to") || "home";
      render();
      return;
    }
    if (act === "signout") {
      state.signedOut = true;
      save();
      screen = "login";
      render();
      showToast("حسابك محفوظ. الدخول الجاي من غير بيانات جديدة.");
      return;
    }
    if (act === "copy") {
      var text = el.getAttribute("data-text") || "";
      if (window.FeloosNative && FeloosNative.copyText) FeloosNative.copyText(text);
      else if (navigator.clipboard) navigator.clipboard.writeText(text);
      showToast("تم النسخ");
      return;
    }
    if (act === "share") {
      var msg = (el.getAttribute("data-text") || "") + " كود الدعوة: " + state.refCode;
      if (!state.inviteRewardClaimed) {
        state.inviteRewardClaimed = true;
        state.coins += 50;
        save();
        playSfx("coins");
        showToast("اتضافت 50 عملة لمشاركة الدعوة مرة واحدة");
      } else {
        showToast("مكافأة الدعوة اتاخدت قبل كده على هذا الجهاز");
      }
      if (window.FeloosNative && FeloosNative.shareText) FeloosNative.shareText(msg);
      else if (navigator.share) navigator.share({ text: msg }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(msg).then(function(){ showToast("تم نسخ الدعوة والكود"); }).catch(function(){ showToast("انسخ الدعوة والكود يدويًا"); });
      else showToast("انسخ الدعوة والكود يدويًا");
    }
  });

  window.feloosBack = function () {
    var ad = $("ad");
    if (ad && !ad.hidden) {
      if (introResolve) closeIntro("skip");
      return;
    }
    var coins = $("coins");
    if (coins && !coins.hidden) {
      closeCoins(false);
      return;
    }
    if (screen === "quiz") {
      screen = "result";
      render();
      return;
    }
    if (screen === "withdraw") {
      screen = "wallet";
      render();
      return;
    }
    if (screen === "privacy" || screen === "terms") {
      screen = backTo || "login";
      render();
      return;
    }
    if (screen === "levels" || screen === "result" || screen === "wallet" || screen === "invite") {
      screen = "home";
      render();
      return;
    }
    if (window.FeloosNative && FeloosNative.finishApp) FeloosNative.finishApp();
  };

  window.feloosSilence = function () {
    audible = false;
    freezeClock();
  };

  window.feloosOnResume = function () {
    audible = true;
    thawClock();
    if (screen === "quiz" && state.open && reveal === null) {
      if (Date.now() >= state.open.deadline) answer(-1);
      else startClock();
    }
  };

  document.addEventListener("visibilitychange", function () {
    if (document.hidden) window.feloosSilence();
    else window.feloosOnResume();
  });

  window.setInterval(function () {
    if (processMatureWithdrawals()) {
      save();
      if (screen === "wallet") render();
    }
  }, 30000);

  state = load();
  if (!state.seen) state.seen = { easy: [], medium: [], hard: [] };
  if (!state.round) state.round = { gems: 0, correct: 0, total: 0 };
  if (!state.withdrawals) state.withdrawals = [];
  processMatureWithdrawals();
  save();
  preloadNativeAd();
  document.addEventListener("pointerdown", function unlock() {
    try {
      var silent = new Audio("data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=");
      var playing = silent.play();
      if (playing && playing.catch) playing.catch(function () {});
    } catch (e) {}
  }, { once: true });
  if (state.onboarded && !state.signedOut) {
    if (state.open) resumeIfNeeded();
    else screen = "home";
  } else screen = "login";
  render();
})();
